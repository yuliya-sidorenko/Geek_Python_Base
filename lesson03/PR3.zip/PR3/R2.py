def user_print(**user_opt) -> None:

    print(
        f'Имя: {user_opt.get("name")}, Фамилия: {user_opt.get("surname")}, Год рождения: {user_opt.get("born_y")}, Город проживания: {user_opt.get("city")}, email: {user_opt.get("email")}, Телефон: {user_opt.get("phone")}')


user = {
    'name': 'Алексей',
    'surname': 'Волков',
    'born_y': '2000',
    'city': 'Москва',
    'email': 'avokov@mail.ru',
    'phone': '35468135',
}

user_print(**user)
