def int_func(text: str) -> str:
    if not text.isascii() and not text.isalpha():
        raise ValueError(f'Слово {text} содержит не латинские символы')

    if not text.islower():
        raise ValueError(f'Слово {text} содержит не только строчные символы')
    return text.title()

text = input("Введите слово из строчных латинских букв ")
print(int_func(text))