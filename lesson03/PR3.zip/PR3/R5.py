def my_sum():
    sum_res = 0
    end = False
    while end == False:
        number = input('Введите  числа, разделенные пробелом или введите L для выхода из программы - ').split()

        res = 0
        for el in range(len(number)):
            if number[el] == 'L' or number[el] == 'L' or number[el] == 'L' or number[el] == 'L':
                end = True
                break
            else:
                res = res + int(number[el])
        sum_res = sum_res + res
        print(f'Текущая сумма {sum_res}')
    print(f'Итоговая сумма {sum_res}')


my_sum()