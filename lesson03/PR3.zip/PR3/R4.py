x = float(input("Введите действительное положительное число>>"))
y = int(input("Введите целое отрициательное число"))
yy = abs(y)
def my_func(x ,y):
    if yy<=1:
        return round(1/x, 3)
    else:
     i = 2
     z = x
     while i <= yy:
        x = x*z
        i = i+1
        print(x)
    return round(1/x, 3)
print(F'Ответ-{my_func(x ,y)}')
