def D():
    try:
        A = int(input("Введите делимое >>>"))
        B = int(input("Введите делитель >>>"))
        C = A / B
    except ValueError:
        return 'Value error'
    except ZeroDivisionError:
        return "Деление на ноль запрещено!"
    return round(C, 2)
print(D())
