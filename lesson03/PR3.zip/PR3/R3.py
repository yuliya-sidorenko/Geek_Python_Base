a = int(input("Введите первое число "))
b = int(input("Введите второе число "))
c = int(input("Введите третье число "))
def my_func(ar_1, ar_2, ar_3):
    if ar_1 >= ar_3 and ar_2 >= ar_3:
        return ar_1 + ar_2
    elif ar_1 > ar_2 and ar_1 < ar_3:
        return ar_1 + ar_3
    else:
        return ar_2 + ar_3
print(F'Ответ - {my_func(a, b, c)}')