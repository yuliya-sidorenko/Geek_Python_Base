"""
3. Реализовать функцию my_func(), которая принимает три позиционных аргумента,
и возвращает сумму наибольших двух аргументов.
"""


def my_func(*args):
    list_end = set(args)
    list_end.remove(min(list_end))
    return sum(list_end)


print(f'Сумма двух наибольших аргументов: {my_func(int(input("Введите первое число: ")), int(input("Введите второе число: ")), int(input("Введите третье число: ")))}')
